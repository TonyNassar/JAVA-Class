public class Transport extends GenericShip
{
    private int Mats;
    
    public Transport()
    {
        super();
        Mats = 100;
    }
    public Transport(/*int Crew, int Cost, String shipName, */int Mats)
    {
        //super(Crew, Cost, shipName);
        this.Mats = Mats;
    }

    public int getMats() 
    {
        return Mats;
    }

    public void setMats(int Mats) 
    {
        this.Mats = Mats;
    }
    
    public String HelpMe()
    {
        String str = "Help! We are under attack!";
        
        return str;
    }
    public String toString()
    {
        String str;
        
        str = super.toString() + "\nYou have " + Mats  + " materials left.\n" +
                HelpMe();
        
        return str;
    }
}
