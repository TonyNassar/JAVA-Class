public abstract class GenericShip 
{
    private int Crew;
    private int Cost;
    private String shipName;
    
    public GenericShip()
    {
        Crew = 10;
        Cost = 5000;
        shipName = "S.S. Default";
    }
    public GenericShip(int Crew, int Cost, String shipName)
    {
        this.Crew = Crew;
        this.Cost = Cost;
        this.shipName = shipName;
    }

    public int getCrew() 
    {
        return Crew;
    }

    public void setCrew(int Crew) 
    {
        this.Crew = Crew;
    }

    public int getCost() 
    {
        return Cost;
    }

    public void setCost(int Cost) 
    {
        this.Cost = Cost;
    }
    
    public String getShipName() 
    {
        return shipName;
    }

    public void setShipName(String shipName) 
    {
        this.shipName = shipName;
    }
    
    public String toString()
    {
        String str;
        
        str = "Crew: " + Crew +
              "\nCost: " + Cost +
              "\nship Name: " + shipName;
        
        return str;
    }
}
