
public class GalaticRidgeWarriors 
{
    public static void main(String[] args)
    {
        Transport trs = new Transport();
        Warship wrs = new Warship();
        ScienceVessel scv = new ScienceVessel();
        
        System.out.println(trs);
        System.out.println(wrs);
        System.out.println(scv);
        scv.LaunchProbes();
    }
}
