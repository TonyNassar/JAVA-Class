public class ScienceVessel extends GenericShip 
{
    private int Probes;
    private int sciAboard;
    private String chiefResearcher;
    
    public ScienceVessel()
    {
        Probes = 10;
        sciAboard = 25;
        chiefResearcher = "Cochane";
    }
    public ScienceVessel(/*int Crew, int Cost, String shipName, */int Probes, 
            int sciAboard, String chiefResearcher)
    {
        //super(Crew, Cost, shipName);
        this.Probes = Probes;
        this.sciAboard = sciAboard;
        this.chiefResearcher = chiefResearcher;
    }
    public int getProbes() 
    {
        return Probes;
    }

    public void setProbes(int Probes) 
    {
        this.Probes = Probes;
    }

    public int getSciAboard() 
    {
        return sciAboard;
    }

    public void setSciAboard(int sciAboard) 
    {
        this.sciAboard = sciAboard;
    }

    public String getChiefResearcher() 
    {
        return chiefResearcher;
    }

    public void setChiefResearcher(String chiefResearcher) 
    {
        this.chiefResearcher = chiefResearcher;
    }
    
    public int LaunchProbes()
    {
        while(Probes > 0)
        {
            System.out.println("We are lauching the probe sir");
            Probes--;
            System.out.println("You have " + Probes + " left.");
        }
        System.out.println("Sorry sir, there are no more probes left.");
        return Probes;
    }
    public String toString()
    {
        String str;
        
        str = super.toString() + "\nYou have " + sciAboard + " scientist "
                + "aboard the ship.\nThe chief researcher is " +
                chiefResearcher + "."+ "\nyou have " + Probes + 
                " Probes.";
        
        return str;
    }
    
}
